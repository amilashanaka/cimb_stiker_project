//
//  ContainerContrloler.swift
//  WAStickersThirdParty
//
//  Created by Benjamin Lim on 3/26/19.
//  Copyright © 2019 WhatsApp. All rights reserved.
//
import Foundation
import UIKit

class ContainerController: UIViewController {
    
//    func setupTabBar() {
//        let sizeRatio: CGFloat = 0.5
//        let homeController = UINavigationController(rootViewController: HomeController())
//        homeController.tabBarItem.image = #imageLiteral(resourceName: "stickerpack").resized(withPercentage: sizeRatio)
//        homeController.tabBarItem.title = "STICKERS"
//
//        let howToController = UINavigationController(rootViewController: HowToController())
//        howToController.tabBarItem.image = #imageLiteral(resourceName: "howto").resized(withPercentage: sizeRatio)
//        howToController.tabBarItem.title = "HOW-TO?"
//
//        let faqController = UINavigationController(rootViewController: FaqsController())
//        faqController.tabBarItem.image = #imageLiteral(resourceName: "faq").resized(withPercentage: sizeRatio)
//        faqController.tabBarItem.title = "FAQ"
//
//        let suggestionController = UINavigationController(rootViewController: SuggestionsController())
//        suggestionController.tabBarItem.image = #imageLiteral(resourceName: "suggestion").resized(withPercentage: sizeRatio)
//        suggestionController.tabBarItem.title = "SUGGESTION"
//
//        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: Constants.FONT_FAMILY_SEMIBOLD, size: 8)!], for: .normal)
//        UITabBarItem.appearance().titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -6)
//        UITabBar.appearance().tintColor = AppColor.SalmonRed
//        tabBar.unselectedItemTintColor = AppColor.SalmonRedDark
//        viewControllers = [homeController, howToController, faqController, suggestionController]
  
    
    // MARK: - Init
    override func viewDidLoad() {
        super.viewDidLoad()
       // setupTabBar()
    }

}
