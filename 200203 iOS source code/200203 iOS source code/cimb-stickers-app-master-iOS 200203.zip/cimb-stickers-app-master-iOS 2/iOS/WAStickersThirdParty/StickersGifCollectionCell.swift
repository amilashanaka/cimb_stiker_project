//
//  StickersGifCollectionCell.swift
//  WAStickersThirdParty
//
//  Created by AXAT Mac mini 3 (2019) on 30/12/19.
//  Copyright © 2019 WhatsApp. All rights reserved.
//

import UIKit

class StickersGifCollectionCell: UICollectionViewCell {

    @IBOutlet weak var StickersImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
