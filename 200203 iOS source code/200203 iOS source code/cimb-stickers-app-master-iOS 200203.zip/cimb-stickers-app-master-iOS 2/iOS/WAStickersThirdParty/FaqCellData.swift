//
//  FaqCellData.swift
//  WAStickersThirdParty
//
//  Created by Benjamin Lim on 4/5/19.
//  Copyright © 2019 WhatsApp. All rights reserved.
//

import Foundation

struct FaqCellData {
    var question = String()
    var answer = String()
}
